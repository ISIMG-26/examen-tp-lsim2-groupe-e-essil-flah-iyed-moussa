/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | compte.js
   Page Mon Compte — chargement AJAX des réservations
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

const contenu = document.getElementById("contenu");

/* ── Formate une date "YYYY-MM-DD" en "DD/MM/YYYY" ── */
function fmtDate(str) {
  if (!str) return "—";
  const [y, m, d] = str.split("-");
  return `${d}/${m}/${y}`;
}

/* ── Badge statut ── */
function badgeStatut(statut) {
  const labels = { confirmee: "Confirmée", en_attente: "En attente", annulee: "Annulée" };
  return `<span class="badge-statut badge-${statut}">${labels[statut] || statut}</span>`;
}

/* ── Bouton annuler (désactivé si passé ou déjà annulé) ── */
function btnAnnuler(resa) {
  const futur = new Date(resa.arrivee) > new Date();
  const annulable = futur && resa.statut !== "annulee";
  return annulable
    ? `<button class="btn-annuler" onclick="annulerResa(${resa.id}, this)">Annuler</button>`
    : `<button class="btn-annuler" disabled>—</button>`;
}

/* ── Rend le tableau des réservations ── */
function renderReservations(reservations) {
  if (!reservations || reservations.length === 0) {
    return `<div class="vide-msg">
      <span>🏨</span>
      <p>Aucune réservation pour le moment.</p>
      <a href="reservation.html" class="btn-hero" style="display:inline-block;margin-top:1rem">Faire une réservation</a>
    </div>`;
  }

  const lignes = reservations.map(r => `
    <tr id="resa-row-${r.id}">
      <td>#${r.id}</td>
      <td>${r.chambre}</td>
      <td>${fmtDate(r.arrivee)}</td>
      <td>${fmtDate(r.depart)}</td>
      <td>${r.nuits} nuit${r.nuits > 1 ? "s" : ""}</td>
      <td><strong style="color:var(--or)">${parseInt(r.total).toLocaleString("fr-TN")} TND</strong></td>
      <td>${badgeStatut(r.statut)}</td>
      <td>${btnAnnuler(r)}</td>
    </tr>
  `).join("");

  return `
    <div class="resa-table-wrapper">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Chambre</th>
            <th>Arrivée</th>
            <th>Départ</th>
            <th>Durée</th>
            <th>Total</th>
            <th>Statut</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>${lignes}</tbody>
      </table>
    </div>`;
}

/* ── Rend la page complète ── */
function renderCompte(data) {
  const u = data.user;
  const r = data.reservations;

  const total    = r.length;
  const confirmees = r.filter(x => x.statut === "confirmee").length;
  const enAttente  = r.filter(x => x.statut === "en_attente").length;
  const depense    = r.filter(x => x.statut !== "annulee").reduce((s, x) => s + parseInt(x.total), 0);

  contenu.innerHTML = `
    <!-- En-tête utilisateur -->
    <div class="compte-header">
      <div class="compte-avatar">👤</div>
      <div class="compte-infos">
        <h2>${u.prenom} ${u.nom}</h2>
        <p>📧 ${u.email}</p>
        ${u.telephone ? `<p>📞 ${u.telephone}</p>` : ""}
        <p style="font-size:.78rem;color:rgba(255,255,255,0.35)">Membre depuis le ${fmtDate(u.cree_le ? u.cree_le.split(" ")[0] : "")}</p>
      </div>
      <a href="../back/logout.php" class="btn-deconnexion">🚪 Déconnexion</a>
    </div>

    <!-- Stats rapides -->
    <div class="compte-stats">
      <div class="stat-card">
        <div class="stat-val">${total}</div>
        <div class="stat-label">Réservation${total > 1 ? "s" : ""} au total</div>
      </div>
      <div class="stat-card">
        <div class="stat-val">${confirmees}</div>
        <div class="stat-label">Confirmée${confirmees > 1 ? "s" : ""}</div>
      </div>
      <div class="stat-card">
        <div class="stat-val">${enAttente}</div>
        <div class="stat-label">En attente</div>
      </div>
      <div class="stat-card">
        <div class="stat-val">${depense.toLocaleString("fr-TN")}</div>
        <div class="stat-label">TND dépensés</div>
      </div>
    </div>

    <!-- Liste réservations -->
    <p class="reservations-titre">🏨 Mes réservations</p>
    ${renderReservations(r)}
  `;
}

/* ── Annuler une réservation via AJAX ── */
async function annulerResa(id, btn) {
  if (!confirm("Confirmer l'annulation de cette réservation ?")) return;

  btn.disabled = true;
  btn.textContent = "⏳";

  try {
    const data = new FormData();
    data.append("id", id);
    const resp = await fetch("../back/annuler_reservation.php", { method: "POST", body: data });
    const json = await resp.json();

    if (json.success) {
      afficherToast("✦ Réservation annulée.");
      // Mettre à jour le badge sans recharger la page (UPDATE DOM)
      const row = document.getElementById("resa-row-" + id);
      if (row) {
        const badgeCell = row.querySelector(".badge-statut");
        if (badgeCell) {
          badgeCell.className   = "badge-statut badge-annulee";
          badgeCell.textContent = "Annulée";
        }
        btn.disabled    = true;
        btn.textContent = "—";
      }
    } else {
      afficherToast("⚠ " + json.message, "error");
      btn.disabled    = false;
      btn.textContent = "Annuler";
    }
  } catch {
    afficherToast("⚠ Erreur réseau.", "error");
    btn.disabled    = false;
    btn.textContent = "Annuler";
  }
}

/* ── Chargement initial via AJAX ── */
(async function chargerCompte() {
  try {
    const resp = await fetch("../back/compte.php");
    const json = await resp.json();

    if (!json.success) {
      // Non connecté → rediriger vers auth
      contenu.innerHTML = `
        <div class="non-connecte">
          <h2>Accès réservé</h2>
          <p>Vous devez être connecté pour accéder à votre compte.</p>
          <a href="auth.html" class="btn-hero">Se connecter</a>
        </div>`;
      return;
    }

    renderCompte(json);

  } catch {
    contenu.innerHTML = `
      <div class="non-connecte">
        <h2>Erreur de chargement</h2>
        <p>Impossible de contacter le serveur. Vérifiez votre connexion.</p>
      </div>`;
  }
})();
