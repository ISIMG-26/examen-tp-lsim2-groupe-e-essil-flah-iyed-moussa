/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | script.js
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

// ─── Prix des chambres ───
const PRIX = {
  "Suite Romaine": 250,
  "Suite Amazighe": 380,
  "Suite Carthaginoise": 580,
};

/* ─────────────────────────────────────────────────
     UTILITAIRES
  ───────────────────────────────────────────────── */
function $(id) { return document.getElementById(id); }
function $q(sel) { return document.querySelector(sel); }
function $qa(sel) { return document.querySelectorAll(sel); }

function afficherToast(msg, type = "ok") {
  const toast = $("toast");
  if (!toast) return;
  toast.textContent = msg;
  toast.style.borderLeftColor = type === "error" ? "#8B2020" : "var(--or)";
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3500);
}

function afficherErreur(champId, msg) {
  const champ = $(champId);
  if (!champ) return;
  let err = champ.parentElement.querySelector(".msg-erreur");
  if (!err) {
    err = document.createElement("span");
    err.className = "msg-erreur";
    champ.parentElement.appendChild(err);
  }
  err.textContent = msg;
  champ.classList.add("champ-invalide");
}

function effacerErreur(champId) {
  const champ = $(champId);
  if (!champ) return;
  const err = champ.parentElement.querySelector(".msg-erreur");
  if (err) err.textContent = "";
  champ.classList.remove("champ-invalide");
}

/* ─────────────────────────────────────────────────
     1. HAMBURGER MENU
  ───────────────────────────────────────────────── */
const hamburger = $("hamburger");
const navLinks  = $("navLinks");

if (hamburger && navLinks) {
  hamburger.addEventListener("click", () => {
    navLinks.classList.toggle("open");
    hamburger.setAttribute("aria-expanded", navLinks.classList.contains("open"));
  });
  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => navLinks.classList.remove("open"));
  });
}

/* ─────────────────────────────────────────────────
     2. NAVBAR — rétréci au scroll
  ───────────────────────────────────────────────── */
window.addEventListener("scroll", () => {
  const navbar = $("navbar");
  if (!navbar) return;
  if (window.scrollY > 60) {
    navbar.style.height     = "52px";
    navbar.style.boxShadow  = "0 4px 20px rgba(0,0,0,.4)";
  } else {
    navbar.style.height     = "66px";
    navbar.style.boxShadow  = "none";
  }
});

/* ─────────────────────────────────────────────────
     3. DATE MINIMALE = aujourd'hui
  ───────────────────────────────────────────────── */
const inputArr = $("arrivee");
const inputDep = $("depart");

if (inputArr && inputDep) {
  const today = new Date().toISOString().split("T")[0];
  inputArr.min = today;
  inputDep.min = today;

  inputArr.addEventListener("change", () => {
    const arr = new Date(inputArr.value);
    arr.setDate(arr.getDate() + 1);
    inputDep.min = arr.toISOString().split("T")[0];
    if (inputDep.value && inputDep.value <= inputArr.value) {
      inputDep.value = arr.toISOString().split("T")[0];
    }
    calculerRecap();
  });
}

/* ─────────────────────────────────────────────────
     4. RÉCAPITULATIF DYNAMIQUE
  ───────────────────────────────────────────────── */
function calculerRecap() {
  const selectCh = $("chambre");
  const rChambre = $("r-chambre");
  const rDuree   = $("r-duree");
  const rTotal   = $("r-total");
  if (!selectCh || !rChambre) return;

  const chambre = selectCh.value;
  const arr = inputArr ? inputArr.value : "";
  const dep = inputDep ? inputDep.value : "";

  if (!chambre) {
    rChambre.textContent = rDuree.textContent = rTotal.textContent = "—";
    return;
  }
  rChambre.textContent = chambre;

  if (arr && dep && dep > arr) {
    const nuits = Math.round((new Date(dep) - new Date(arr)) / 86400000);
    const total = nuits * PRIX[chambre];
    rDuree.textContent = nuits + " nuit" + (nuits > 1 ? "s" : "");
    rTotal.textContent = total.toLocaleString("fr-TN") + " TND";
  } else {
    rDuree.textContent = rTotal.textContent = "—";
  }
}

const selectCh = $("chambre");
if (selectCh) selectCh.addEventListener("change", calculerRecap);
if (inputDep)  inputDep.addEventListener("change", calculerRecap);

/* ─────────────────────────────────────────────────
     5. CHOISIR UNE CHAMBRE (depuis les cards)
  ───────────────────────────────────────────────── */
function choisirChambre(nom, prix) {
  const sel = $("chambre");
  if (sel) { sel.value = nom; calculerRecap(); }
  const section = $("reservation");
  if (section) section.scrollIntoView({ behavior: "smooth" });
  afficherToast("✦ " + nom + " sélectionnée — " + prix + " TND/nuit");
}

/* ─────────────────────────────────────────────────
     6. VALIDATION FORMULAIRE RÉSERVATION
  ───────────────────────────────────────────────── */
function validerFormResa() {
  let valide = true;
  const champs = ["nom", "email", "tel", "chambre", "arrivee", "depart"];

  champs.forEach(id => effacerErreur(id));

  const nom = $("nom");
  if (nom && nom.value.trim().length < 2) {
    afficherErreur("nom", "Nom trop court (min. 2 caractères).");
    valide = false;
  }

  const email = $("email");
  if (email) {
    const reEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!reEmail.test(email.value.trim())) {
      afficherErreur("email", "Format d'email invalide.");
      valide = false;
    }
  }

  const tel = $("tel");
  if (tel && tel.value.trim().length < 8) {
    afficherErreur("tel", "Numéro de téléphone invalide.");
    valide = false;
  }

  const chambre = $("chambre");
  if (chambre && !chambre.value) {
    afficherErreur("chambre", "Veuillez sélectionner une chambre.");
    valide = false;
  }

  if (inputArr && !inputArr.value) {
    afficherErreur("arrivee", "Date d'arrivée requise.");
    valide = false;
  }

  if (inputDep && !inputDep.value) {
    afficherErreur("depart", "Date de départ requise.");
    valide = false;
  } else if (inputArr && inputDep && inputDep.value <= inputArr.value) {
    afficherErreur("depart", "Le départ doit être après l'arrivée.");
    valide = false;
  }

  return valide;
}

/* ─────────────────────────────────────────────────
     7. SOUMISSION DU FORMULAIRE RÉSERVATION (AJAX)
  ───────────────────────────────────────────────── */
const formResa = $("formResa");
if (formResa) {
  formResa.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!validerFormResa()) return;

    const btn = formResa.querySelector(".btn-submit");
    btn.textContent = "⏳ Envoi en cours...";
    btn.disabled = true;

    try {
      const resp = await fetch("../back/reservation.php", {
        method: "POST",
        body: new FormData(formResa),
      });
      const json = await resp.json();

      if (json.success) {
        afficherToast("✦ Réservation confirmée ! Merci.");
        formResa.reset();
        ["r-chambre", "r-duree", "r-total"].forEach(id => {
          if ($(id)) $(id).textContent = "—";
        });
      } else {
        afficherToast("⚠ " + json.message, "error");
      }
    } catch {
      afficherToast("✦ Réservation reçue ! Nous vous contactons bientôt.");
      formResa.reset();
    } finally {
      btn.textContent = "✦ Confirmer la Réservation ✦";
      btn.disabled = false;
    }
  });
}

/* ─────────────────────────────────────────────────
     8. VALIDATION FORMULAIRE CONNEXION / INSCRIPTION
  ───────────────────────────────────────────────── */
const formLogin = $("formLogin");
if (formLogin) {
  formLogin.addEventListener("submit", async (e) => {
    e.preventDefault();
    let valide = true;

    ["login-email", "login-mdp"].forEach(id => effacerErreur(id));

    const emailEl = $("login-email");
    const mdpEl   = $("login-mdp");

    if (emailEl && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailEl.value.trim())) {
      afficherErreur("login-email", "Email invalide."); valide = false;
    }
    if (mdpEl && mdpEl.value.length < 6) {
      afficherErreur("login-mdp", "Mot de passe trop court."); valide = false;
    }

    if (!valide) return;

    const btn = formLogin.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "⏳ Connexion...";

    try {
      const data = new FormData();
      data.append("email", emailEl.value.trim());
      data.append("mot_de_passe", mdpEl.value);
      const resp = await fetch("../back/login.php", { method: "POST", body: data });
      const json = await resp.json();
      if (json.success) {
        afficherToast("✦ " + json.message);
        setTimeout(() => window.location.href = "../index.php", 1500);
      } else {
        afficherToast("⚠ " + json.message, "error");
      }
    } catch {
      afficherToast("⚠ Erreur de connexion au serveur.", "error");
    } finally {
      btn.disabled = false; btn.textContent = "Se connecter";
    }
  });
}

const formInscription = $("formInscription");
if (formInscription) {
  // AJAX — vérification email en temps réel
  const emailInsc = $("insc-email");
  if (emailInsc) {
    emailInsc.addEventListener("blur", async () => {
      effacerErreur("insc-email");
      const val = emailInsc.value.trim();
      if (!val || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) return;
      try {
        const resp = await fetch("../back/check_email.php?email=" + encodeURIComponent(val));
        const json = await resp.json();
        if (!json.disponible) {
          afficherErreur("insc-email", json.message);
        }
      } catch (e) { /* silencieux */ }
    });
  }

  formInscription.addEventListener("submit", async (e) => {
    e.preventDefault();
    let valide = true;

    ["insc-nom", "insc-prenom", "insc-email", "insc-tel", "insc-mdp", "insc-mdp2"].forEach(id => effacerErreur(id));

    const nomEl    = $("insc-nom");
    const prenomEl = $("insc-prenom");
    const emailEl  = $("insc-email");
    const telEl    = $("insc-tel");
    const mdpEl    = $("insc-mdp");
    const mdp2El   = $("insc-mdp2");

    if (nomEl && nomEl.value.trim().length < 2)   { afficherErreur("insc-nom", "Nom requis."); valide = false; }
    if (prenomEl && prenomEl.value.trim().length < 2) { afficherErreur("insc-prenom", "Prénom requis."); valide = false; }
    if (emailEl && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailEl.value.trim())) { afficherErreur("insc-email", "Email invalide."); valide = false; }
    if (telEl && telEl.value.trim().length < 8)   { afficherErreur("insc-tel", "Téléphone invalide."); valide = false; }
    if (mdpEl && mdpEl.value.length < 6)          { afficherErreur("insc-mdp", "Minimum 6 caractères."); valide = false; }
    if (mdpEl && mdp2El && mdpEl.value !== mdp2El.value) { afficherErreur("insc-mdp2", "Les mots de passe ne correspondent pas."); valide = false; }

    if (!valide) return;

    const btn = formInscription.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "⏳ Inscription...";

    try {
      const data = new FormData();
      data.append("nom",           nomEl.value.trim());
      data.append("prenom",        prenomEl.value.trim());
      data.append("email",         emailEl.value.trim());
      data.append("telephone",     telEl.value.trim());
      data.append("mot_de_passe",  mdpEl.value);
      data.append("mot_de_passe2", mdp2El.value);
      const resp = await fetch("../back/inscription.php", { method: "POST", body: data });
      const json = await resp.json();
      if (json.success) {
        afficherToast("✦ " + json.message);
        setTimeout(() => window.location.href = "../index.php", 1500);
      } else {
        afficherToast("⚠ " + json.message, "error");
      }
    } catch {
      afficherToast("⚠ Erreur de connexion au serveur.", "error");
    } finally {
      btn.disabled = false; btn.textContent = "Créer mon compte";
    }
  });
}

/* ─────────────────────────────────────────────────
     9. TABS : CONNEXION / INSCRIPTION
  ───────────────────────────────────────────────── */
const tabs = $qa(".auth-tab");
tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    const cible = tab.dataset.tab;
    $qa(".auth-panel").forEach(p => p.classList.remove("active"));
    const panel = $(cible);
    if (panel) panel.classList.add("active");
  });
});

/* ─────────────────────────────────────────────────
     10. ANIMATION AU SCROLL (Intersection Observer)
  ───────────────────────────────────────────────── */
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity   = "1";
        entry.target.style.transform = "translateY(0)";
      }
    });
  },
  { threshold: 0.12 }
);

$qa(".chambre-card, .service-item, .gal-item").forEach((el) => {
  el.style.opacity   = "0";
  el.style.transform = "translateY(30px)";
  el.style.transition = "opacity .6s ease, transform .6s ease";
  observer.observe(el);
});
