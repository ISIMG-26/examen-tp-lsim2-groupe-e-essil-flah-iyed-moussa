<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Nomade — Hôtel de Luxe | Accueil</title>
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <nav id="navbar">
      <div class="logo"><em>Nomade</em><span> — Hôtel de Luxe</span></div>
      <ul class="nav-links" id="navLinks">
        <li><a href="index.php">Accueil</a></li>
        <li><a href="html/chambre.html">Chambres</a></li>
        <li><a href="html/service.html">Services</a></li>
        <li><a href="html/galerie.html">Galerie</a></li>
        <li><a href="html/reservation.html" class="btn-nav">Réserver</a></li>
        <li><a href="html/auth.html">Connexion</a></li>
        <li><a href="html/compte.html">Mon Compte</a></li>
      </ul>
      <div class="hamburger" id="hamburger" aria-expanded="false">
        <span></span><span></span><span></span>
      </div>
    </nav>

    <section id="hero">
      <div class="hero-content">
        <p class="tifinagh">ⵣ ⴰ ⵎ ⴰ ⵣ ⵉ ⵖ</p>
        <h1><em>Nomade</em></h1>
        <p class="hero-sub">
          Où l'héritage romain, amazigh et carthaginois renaît dans un luxe moderne
        </p>
        <a href="html/reservation.html" class="btn-hero">Réserver Maintenant</a>
      </div>
      <div class="hero-arc"></div>
      <div class="hero-scroll">↓</div>
    </section>

    <div class="bande-deco"></div>

    <footer>
      <div class="footer-top">
        <div class="footer-brand">
          <div class="logo" style="font-size:1.6rem"><em>Nomade</em></div>
          <p>L'âme de trois civilisations,<br />le confort du XXIe siècle.</p>
          <p class="tifinagh-footer">ⵣ ⴻ ⵍ ⵍ ⴰ</p>
        </div>
        <div class="footer-col">
          <h5>Navigation</h5>
          <a href="index.php">Accueil</a>
          <a href="html/chambre.html">Chambres</a>
          <a href="html/service.html">Services</a>
          <a href="html/galerie.html">Galerie</a>
          <a href="html/reservation.html">Réservation</a>
        </div>
        <div class="footer-col">
          <h5>Contact</h5>
          <p>📍 Route de Carthage, Tunis 2016</p>
          <p>📞 +216 71 000 000</p>
          <p>✉️ contact@nomade.tn</p>
        </div>
      </div>
      <div class="bande-deco"></div>
      <p class="footer-copy">© 2025–2026 Nomade Hôtel. Réalisé par <strong>Essil Flah</strong> &amp; <strong>Mohamed Iyed Moussa</strong>.</p>
    </footer>

    <div class="toast" id="toast"></div>
    <script src="js/script.js"></script>
  </body>
</html>
