-- ═══════════════════════════════════════════════════
--   NOMADE — Hôtel de Luxe | Base de données MySQL
--   Réalisé par : Essil Flah & Mohamed Iyed Moussa
-- ═══════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS nomade_hotel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nomade_hotel;

-- ─── Table des utilisateurs ───
CREATE TABLE IF NOT EXISTS utilisateurs (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nom        VARCHAR(100) NOT NULL,
    prenom     VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    telephone  VARCHAR(30),
    cree_le    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─── Table des réservations ───
CREATE TABLE IF NOT EXISTS reservations (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT,
    nom          VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL,
    tel          VARCHAR(30)  NOT NULL,
    chambre      VARCHAR(100) NOT NULL,
    arrivee      DATE         NOT NULL,
    depart       DATE         NOT NULL,
    adultes      INT          DEFAULT 1,
    enfants      INT          DEFAULT 0,
    nuits        INT          NOT NULL,
    total        INT          NOT NULL,
    message      TEXT,
    statut       ENUM('en_attente','confirmee','annulee') DEFAULT 'en_attente',
    cree_le      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL
);

-- ─── Données de démonstration ───
INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone) VALUES
('Ben Ali', 'Ahmed', 'ahmed@email.com', '$2y$10$abcdefghijklmnopqrstuuVGZK5h4a5wFQ0ZvD3K3K7Q3K7Q3K7QC', '+216 71 000 001'),
('Trabelsi', 'Sarra', 'sarra@email.com', '$2y$10$abcdefghijklmnopqrstuuVGZK5h4a5wFQ0ZvD3K3K7Q3K7Q3K7QC', '+216 71 000 002');

INSERT INTO reservations (utilisateur_id, nom, email, tel, chambre, arrivee, depart, adultes, enfants, nuits, total, statut) VALUES
(1, 'Ben Ali Ahmed', 'ahmed@email.com', '+216 71 000 001', 'Suite Romaine', '2026-06-10', '2026-06-13', 2, 0, 3, 750, 'confirmee'),
(2, 'Trabelsi Sarra', 'sarra@email.com', '+216 71 000 002', 'Suite Amazighe', '2026-07-01', '2026-07-05', 2, 1, 4, 1520, 'en_attente');
