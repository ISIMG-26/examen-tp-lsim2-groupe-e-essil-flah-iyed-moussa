# 🏨 Nomade — Hôtel de Luxe

> Mini-projet Web — LSIM 2 | Technologies & Programmation Web 2025-2026

## 👥 Membres du groupe

| Nom | Prénom | Section |
|-----|--------|---------|
| Flah | Essil | LSIM2E |
| Moussa | Mohamed Iyed | LSIM2E |

## 📋 Description du projet

**Nomade** est un site web dynamique de type e-commerce pour un hôtel de luxe tunisien inspiré des civilisations romaine, amazighe et carthaginoise. Le site permet aux utilisateurs de consulter les chambres, les services, la galerie, de créer un compte, de se connecter et de réserver en ligne.

## 🗂️ Structure du projet

```
/project-root
├── index.php              ← Page d'accueil
├── README.md
├── html/
│   ├── chambre.html       ← Page des chambres
│   ├── service.html       ← Page des services
│   ├── galerie.html       ← Galerie photos
│   ├── reservation.html   ← Formulaire de réservation
│   └── auth.html          ← Connexion / Inscription
├── css/
│   └── style.css          ← Feuille de styles externe
├── js/
│   └── script.js          ← JavaScript natif (DOM, AJAX, validation)
├── images/
│   └── (photos de l'hôtel)
├── back/
│   ├── connexion.php      ← Configuration PDO
│   ├── login.php          ← Traitement connexion
│   ├── inscription.php    ← Traitement inscription
│   ├── reservation.php    ← Traitement réservation
│   └── check_email.php    ← Vérification email (AJAX)
└── database/
    └── script.sql         ← Script de création base de données
```

## ⚙️ Installation locale (XAMPP / WAMP)

1. Copier le dossier dans `htdocs/` (XAMPP) ou `www/` (WAMP)
2. Importer `database/script.sql` dans phpMyAdmin
3. Vérifier les paramètres dans `back/connexion.php` (host, user, password)
4. Accéder à `http://localhost/nomade_hotel/`

## ✅ Fonctionnalités couvertes

| Partie | Fonctionnalité | Statut |
|--------|---------------|--------|
| 1 | Structure HTML sémantique, 5 pages interconnectées | ✅ |
| 2 | CSS externe, cohérence graphique | ✅ |
| 3 | DOM : hamburger, scroll, animation, récapitulatif dynamique | ✅ |
| 4 | Validation JS : formulaires réservation et inscription | ✅ |
| 5 | AJAX : soumission réservation, vérification email en temps réel | ✅ |
| 6 | PHP : login, inscription, réservation (POST), check_email (GET) | ✅ |
| 7 | MySQL : tables `utilisateurs` + `reservations` (clé étrangère), CRUD | ✅ |
| 8 | Interface soignée, navigation intuitive | ✅ |

## 📌 Répartition des tâches

| Tâche | Responsable |
|-------|-------------|
| HTML (toutes les pages) | Essil Flah |
| CSS (style.css) | Essil Flah |
| JavaScript (script.js) | Mohamed Iyed Moussa |
| PHP back-end | Mohamed Iyed Moussa |
| Base de données SQL | Mohamed Iyed Moussa |
| Page authentification | Essil Flah |
| Tests & débogage | Les deux |
