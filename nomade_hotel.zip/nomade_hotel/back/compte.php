<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Mon Compte (API JSON)
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'connexion.php';

// Vérifier si connecté
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Non connecté.']);
    exit;
}

try {
    $pdo = getConnexion();
    $userId = $_SESSION['user_id'];

    // Infos utilisateur
    $stmt = $pdo->prepare("SELECT id, nom, prenom, email, telephone, cree_le FROM utilisateurs WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'Utilisateur introuvable.']);
        exit;
    }

    // Ses réservations
    $stmt2 = $pdo->prepare("SELECT * FROM reservations WHERE utilisateur_id = ? ORDER BY cree_le DESC");
    $stmt2->execute([$userId]);
    $reservations = $stmt2->fetchAll();

    echo json_encode([
        'success'      => true,
        'user'         => $user,
        'reservations' => $reservations,
    ]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur serveur.']);
}
?>
