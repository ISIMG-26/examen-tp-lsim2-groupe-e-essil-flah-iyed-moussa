<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Connexion utilisateur
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'connexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
    exit;
}

$email = htmlspecialchars(strip_tags(trim($_POST['email'] ?? '')));
$mdp   = $_POST['mot_de_passe'] ?? '';

if (empty($email) || empty($mdp)) {
    echo json_encode(['success' => false, 'message' => 'Email et mot de passe requis.']);
    exit;
}

try {
    $pdo = getConnexion();
    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($mdp, $user['mot_de_passe'])) {
        $_SESSION['user_id']    = $user['id'];
        $_SESSION['user_nom']   = $user['prenom'] . ' ' . $user['nom'];
        $_SESSION['user_email'] = $user['email'];
        echo json_encode(['success' => true, 'message' => 'Connexion réussie ! Bienvenue ' . $user['prenom'] . '.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Email ou mot de passe incorrect.']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur serveur.']);
}
?>
