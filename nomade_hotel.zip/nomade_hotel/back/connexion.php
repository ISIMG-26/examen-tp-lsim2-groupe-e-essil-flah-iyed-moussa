<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Connexion base de données
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

define('DB_HOST', 'localhost');
define('DB_NAME', 'nomade_hotel');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getConnexion() {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        http_response_code(500);
        die(json_encode(['success' => false, 'message' => 'Erreur de connexion à la base de données.']));
    }
}
?>
