<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Déconnexion
═══════════════════════════════════════════════════ */
session_start();
session_destroy();
header('Location: ../html/auth.html');
exit;
?>
