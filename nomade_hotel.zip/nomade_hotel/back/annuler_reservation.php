<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Annuler une réservation
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

session_start();
header('Content-Type: application/json');

require_once 'connexion.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Non connecté.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
    exit;
}

$id = (int)($_POST['id'] ?? 0);
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID invalide.']);
    exit;
}

try {
    $pdo = getConnexion();

    // Vérifier que la réservation appartient bien à cet utilisateur
    $stmt = $pdo->prepare("SELECT id, statut, arrivee FROM reservations WHERE id = ? AND utilisateur_id = ?");
    $stmt->execute([$id, $_SESSION['user_id']]);
    $resa = $stmt->fetch();

    if (!$resa) {
        echo json_encode(['success' => false, 'message' => 'Réservation introuvable.']);
        exit;
    }

    if ($resa['statut'] === 'annulee') {
        echo json_encode(['success' => false, 'message' => 'Déjà annulée.']);
        exit;
    }

    // Vérifier que la date d'arrivée est dans le futur
    if (strtotime($resa['arrivee']) <= time()) {
        echo json_encode(['success' => false, 'message' => 'Impossible d\'annuler une réservation passée.']);
        exit;
    }

    // Annuler (UPDATE)
    $stmt2 = $pdo->prepare("UPDATE reservations SET statut = 'annulee' WHERE id = ?");
    $stmt2->execute([$id]);

    echo json_encode(['success' => true, 'message' => 'Réservation annulée avec succès.']);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur serveur.']);
}
?>
