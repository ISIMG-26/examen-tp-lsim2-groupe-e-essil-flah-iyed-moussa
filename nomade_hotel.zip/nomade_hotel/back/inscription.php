<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Inscription utilisateur
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'connexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
    exit;
}

function nettoyer($val) {
    return htmlspecialchars(strip_tags(trim($val)));
}

$nom    = nettoyer($_POST['nom']    ?? '');
$prenom = nettoyer($_POST['prenom'] ?? '');
$email  = nettoyer($_POST['email']  ?? '');
$tel    = nettoyer($_POST['tel']    ?? '');
$mdp    = $_POST['mot_de_passe']    ?? '';
$mdp2   = $_POST['mot_de_passe2']   ?? '';

// Validation
$erreurs = [];
if (empty($nom))    $erreurs[] = 'Le nom est requis.';
if (empty($prenom)) $erreurs[] = 'Le prénom est requis.';
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL))
                    $erreurs[] = 'Email invalide.';
if (strlen($mdp) < 6)
                    $erreurs[] = 'Le mot de passe doit contenir au moins 6 caractères.';
if ($mdp !== $mdp2) $erreurs[] = 'Les mots de passe ne correspondent pas.';

if (!empty($erreurs)) {
    echo json_encode(['success' => false, 'message' => implode(' ', $erreurs)]);
    exit;
}

try {
    $pdo = getConnexion();

    // Vérifier si email déjà utilisé
    $stmt = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Cet email est déjà utilisé.']);
        exit;
    }

    // Insérer l'utilisateur
    $hash = password_hash($mdp, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe, telephone) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$nom, $prenom, $email, $hash, $tel]);

    $userId = $pdo->lastInsertId();
    $_SESSION['user_id']  = $userId;
    $_SESSION['user_nom'] = $prenom . ' ' . $nom;
    $_SESSION['user_email'] = $email;

    echo json_encode(['success' => true, 'message' => 'Inscription réussie ! Bienvenue ' . $prenom . '.']);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur serveur. Réessayez.']);
}
?>
