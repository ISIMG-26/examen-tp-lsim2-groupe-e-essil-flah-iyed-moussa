<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Traitement réservations
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'connexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée.']);
    exit;
}

function nettoyer($val) {
    return htmlspecialchars(strip_tags(trim($val)));
}

$nom     = nettoyer($_POST['nom']     ?? '');
$email   = nettoyer($_POST['email']   ?? '');
$tel     = nettoyer($_POST['tel']     ?? '');
$chambre = nettoyer($_POST['chambre'] ?? '');
$arrivee = nettoyer($_POST['arrivee'] ?? '');
$depart  = nettoyer($_POST['depart']  ?? '');
$adultes = (int)($_POST['adultes']    ?? 1);
$enfants = (int)($_POST['enfants']    ?? 0);
$message = nettoyer($_POST['message'] ?? '');

// Validation
$erreurs = [];
if (empty($nom))    $erreurs[] = 'Le nom est requis.';
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL))
                    $erreurs[] = 'Email invalide.';
if (empty($tel))    $erreurs[] = 'Le téléphone est requis.';
if (empty($chambre)) $erreurs[] = 'Veuillez choisir une chambre.';
if (empty($arrivee)) $erreurs[] = "La date d'arrivée est requise.";
if (empty($depart))  $erreurs[] = 'La date de départ est requise.';

if (!empty($arrivee) && !empty($depart)) {
    $dateArr = new DateTime($arrivee);
    $dateDep = new DateTime($depart);
    $dateAuj = new DateTime('today');
    if ($dateArr < $dateAuj) $erreurs[] = "La date d'arrivée ne peut pas être dans le passé.";
    if ($dateDep <= $dateArr) $erreurs[] = "La date de départ doit être après l'arrivée.";
}

if (!empty($erreurs)) {
    echo json_encode(['success' => false, 'message' => implode(' ', $erreurs)]);
    exit;
}

// Calcul du prix
$tarifs = [
    'Suite Romaine'       => 250,
    'Suite Amazighe'      => 380,
    'Suite Carthaginoise' => 580,
];
$prixNuit = $tarifs[$chambre] ?? 0;
$nuits    = (new DateTime($arrivee))->diff(new DateTime($depart))->days;
$total    = $nuits * $prixNuit;

// Enregistrement en base de données
try {
    $pdo = getConnexion();
    $userId = $_SESSION['user_id'] ?? null;

    $stmt = $pdo->prepare("INSERT INTO reservations
        (utilisateur_id, nom, email, tel, chambre, arrivee, depart, adultes, enfants, nuits, total, message)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$userId, $nom, $email, $tel, $chambre, $arrivee, $depart, $adultes, $enfants, $nuits, $total, $message]);

    echo json_encode([
        'success' => true,
        'message' => 'Réservation confirmée !',
        'details' => [
            'chambre' => $chambre,
            'nuits'   => $nuits,
            'total'   => $total . ' TND',
        ]
    ]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur lors de l\'enregistrement.']);
}
?>
