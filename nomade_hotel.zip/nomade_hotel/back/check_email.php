<?php
/* ═══════════════════════════════════════════════════
   NOMADE — Hôtel de Luxe | Vérification email (AJAX)
   Réalisé par : Essil Flah & Mohamed Iyed Moussa
═══════════════════════════════════════════════════ */

header('Content-Type: application/json');
require_once 'connexion.php';

$email = htmlspecialchars(strip_tags(trim($_GET['email'] ?? '')));

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['disponible' => false, 'message' => 'Email invalide.']);
    exit;
}

try {
    $pdo = getConnexion();
    $stmt = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $existe = $stmt->fetch();
    echo json_encode([
        'disponible' => !$existe,
        'message'    => $existe ? 'Cet email est déjà utilisé.' : 'Email disponible.'
    ]);
} catch (PDOException $e) {
    echo json_encode(['disponible' => false, 'message' => 'Erreur serveur.']);
}
?>
